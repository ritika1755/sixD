from flask import Flask, request, jsonify
import smtplib
from email.mime.text import MIMEText
from flask_cors import CORS
import spacy

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load SpaCy model
nlp = spacy.load("en_core_web_sm")

# Predefined categories with expanded keywords
CATEGORIES = {
    "Technical": ["error", "bug", "issue", "crash", "server", "connectivity", "not working", "failed"],
    "Billing": ["invoice", "payment", "refund", "bill", "charge", "fee", "amount", "balance"],
    "General Inquiry": ["question", "help", "support", "info", "information", "how to", "assistance"]
}

def categorize_issue(message):
    """Categorize the issue with priority for specific categories."""
    doc = nlp(message.lower())  # Convert message to lowercase for case-insensitive matching

    # Prioritize categories
    for category, keywords in [
        ("Billing", CATEGORIES["Billing"]),
        ("Technical", CATEGORIES["Technical"]),
        ("General Inquiry", CATEGORIES["General Inquiry"])
    ]:
        if any(keyword in doc.text for keyword in keywords):
            print(f"Matched category: {category}")  # Log the matched category
            return category

    return "Uncategorized"  # Default if no keywords match


@app.route('/notify_authority', methods=['POST'])
def notify_authority():
    try:
        # Get JSON data from frontend
        data = request.get_json()
        user_email = data.get('contact', 'no-reply@example.com')
        description = data.get('message', 'No description provided')

        # Categorize the issue
        category = categorize_issue(description)

        # Email content for the company
        authority_email = "abc@gmail.com"
        subject_to_authority = f"New {category} Issue Reported"
        body_to_authority = f"""
        A new {category} issue has been reported:

        Contact: {user_email}
        Category: {category}
        Description: {description}
        """

        # Email content for the user
        subject_to_user = "Issue Reported Successfully"
        body_to_user = f"""
        Dear User,

        Thank you for reporting the issue. Here are the details we received:

        Category: {category}
        Description: {description}

        Our team will address this promptly.

        Regards,
        Company Support
        """

        # Send emails
        send_email(to_email=authority_email, subject=subject_to_authority, body=body_to_authority)
        send_email(to_email=user_email, subject=subject_to_user, body=body_to_user)

        return jsonify({"status": "success", "message": "Emails sent successfully!", "category": category}), 200

    except Exception as e:
        print(f"Error in /notify_authority: {e}")  # Log the error
        return jsonify({"status": "error", "message": str(e)}), 500


def send_email(to_email, subject, body):
    """Send an email using SMTP."""
    smtp_server = "smtp.gmail.com"  # Change this if using a company SMTP server
    smtp_port = 587
    sender_email = "abc@gmail.com"  # Replace with your Gmail address or system email
    sender_password = "password"  # Replace with your App Password or system email password

    # Create the email
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = to_email

    # Send the email
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()  # Upgrade connection to secure
        server.login(sender_email, sender_password)  # Log in to SMTP server
        server.send_message(msg)


if __name__ == "__main__":
    app.run(debug=True, port=5001)